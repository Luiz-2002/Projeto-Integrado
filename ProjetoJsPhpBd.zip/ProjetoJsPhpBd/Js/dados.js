'use strict';

const placa = document.getElementById('placa');
const Descricao = document.getElementById('descricao');
const nomeCliente = document.getElementById('nomeCliente');
const button = document.querySelector('#botao');
const buttonCalcular = document.querySelector('#botaoCalcular');

/* Função post */

function createEntrada(entrada){
	const url = 'http://localhost/michel/ProjetoJsPhpBd/api/index.php/entrada';
                    
	const options = {
		method: 'POST',
		headers: {
			'Content-Type':'application/json'
		},
		body: JSON.stringify(entrada)
	};
    
    fetch(url, options);
}

let entrada;

const getDados = () => {
   entrada = {
		"placa": placa.value,
		"Descricao": Descricao.value,
		"nomeCliente": nomeCliente.value
    }
    createEntrada(entrada);
}

button.addEventListener('click', getDados);

/* Metodo GET */

 // COMEÇO DO GET DOS DADOS///////////////////////////////
const getClientes = () =>{
  const url = `http://localhost/michel/ProjetoJsPhpBd//api/index.php/entrada`;  
  fetch(url).then(response => response.json())
            .then(data =>  repeticao(data));    
}
 
const insertToElement = (element) => {
        
  const tr = document.createElement('tr');
    
    
  tr.classList.add('trFuncional');
 
  tr.innerHTML = `         
    <td class="rsTicket">${element.idVeiculo}</td>
    <td class="rsEntrada">${element.entrada}</td>
    <td class="rsPlacaInfo">${element.placa}</td>
    <td class="rsDescricaoInfo">${element.Descricao}</td>
    <td class="rsClienteInfo">${element.nomeCliente}</td>
    <td class="rsSaida">${element.saida}</td>
    <button id="botaoCalcular" onclick ="updateVeiculo('${element.idVeiculo}')">Saida</button>
    
      
    `;
    
  return tr;   
}


const repeticao = (data) => {
  const container = document.getElementById('table');
  data.forEach(element => {
    container.appendChild(insertToElement(element));
 
  });
 
}
 
getClientes();
//////////////////////////////////////


/* Metodo PUT */

function updateVeiculo(idVeiculo){
	const url = `http://localhost/michel/ProjetoJsPhpBd/api/index.php/entrada/${idVeiculo}`;
                   
	const options = {
		method: 'PUT',
	}
    
    fetch(url, options)
}

const getDadosSaida = () => {
   Saida = {
    
   }
    updateVeiculo(idVeiculo);
}

buttonCalcular.addEventListener('click', getDadosSaida);


