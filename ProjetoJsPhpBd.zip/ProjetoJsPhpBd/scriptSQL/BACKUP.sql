-- MySQL dump 10.13  Distrib 8.0.11, for Win64 (x86_64)
--
-- Host: localhost    Database: dbfastparking
-- ------------------------------------------------------
-- Server version	8.0.11

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tblprecos`
--

DROP TABLE IF EXISTS `tblprecos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `tblprecos` (
  `idPreco` int(11) NOT NULL AUTO_INCREMENT,
  `PrimeiroPreco` decimal(10,0) DEFAULT NULL,
  `DemaisPrecos` decimal(10,0) DEFAULT NULL,
  PRIMARY KEY (`idPreco`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblprecos`
--

LOCK TABLES `tblprecos` WRITE;
/*!40000 ALTER TABLE `tblprecos` DISABLE KEYS */;
INSERT INTO `tblprecos` VALUES (1,10,2);
/*!40000 ALTER TABLE `tblprecos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblreservas`
--

DROP TABLE IF EXISTS `tblreservas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `tblreservas` (
  `idReserva` int(11) NOT NULL AUTO_INCREMENT,
  `idPreco` int(11) NOT NULL,
  `idVeiculo` int(11) NOT NULL,
  PRIMARY KEY (`idReserva`),
  KEY `FK_Reserva_Veiculos` (`idVeiculo`),
  KEY `FK_Reserva_preco` (`idPreco`),
  CONSTRAINT `FK_Reserva_Veiculos` FOREIGN KEY (`idVeiculo`) REFERENCES `tblveiculos` (`idveiculo`),
  CONSTRAINT `FK_Reserva_preco` FOREIGN KEY (`idPreco`) REFERENCES `tblprecos` (`idpreco`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblreservas`
--

LOCK TABLES `tblreservas` WRITE;
/*!40000 ALTER TABLE `tblreservas` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblreservas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblveiculos`
--

DROP TABLE IF EXISTS `tblveiculos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `tblveiculos` (
  `idVeiculo` int(11) NOT NULL AUTO_INCREMENT,
  `nomeCliente` varchar(50) NOT NULL,
  `Descricao` varchar(30) NOT NULL,
  `placa` varchar(10) NOT NULL,
  `idPreco` int(11) NOT NULL,
  `entrada` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `saida` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`idVeiculo`),
  KEY `FK_veiculos_preco` (`idPreco`),
  CONSTRAINT `FK_veiculos_preco` FOREIGN KEY (`idPreco`) REFERENCES `tblprecos` (`idpreco`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblveiculos`
--

LOCK TABLES `tblveiculos` WRITE;
/*!40000 ALTER TABLE `tblveiculos` DISABLE KEYS */;
INSERT INTO `tblveiculos` VALUES (1,'wagner','celta preto','AHB-9517',1,'2020-12-16 18:56:55','2020-12-16 18:58:26'),(2,'jonas','onix rosa','BDB-2417',1,'2020-12-18 17:33:19','2020-12-18 17:35:30'),(3,'Roberto','onix rosa','BDB-2417',1,'2020-12-18 17:34:32','2020-12-18 17:35:34'),(4,'Lucas','fusca amarelo','BDB-2417',1,'2020-12-18 17:35:07','2020-12-18 17:35:35'),(5,'Marcelo','savero branca','GAY-2024',1,'2020-12-18 18:33:58','2020-12-21 17:31:56'),(6,'Celso','corsa de firma','yyy-1111',1,'2020-12-18 19:58:24','2020-12-21 17:32:02'),(10,'Felipe Souza','HB20 Branco','FJY-5174',1,'2020-12-18 19:59:29','2020-12-21 17:32:39'),(11,'Lucas','fusca azul','BDB-2417',1,'2020-12-21 16:31:46','2020-12-21 16:32:26'),(12,'Paul Walker','Skyline Prata','SKL-8314',1,'2020-12-21 16:33:36',NULL),(13,'Jhon Lucas','Golf GTI','KJL-2414',1,'2020-12-21 16:36:06','2020-12-21 19:21:56'),(15,'Marcelo ','Golf GTI','KJL-2414',1,'2020-12-21 17:41:34',NULL),(16,'Henrique e Juliano','Camaro Amarelo','HAB-3180',1,'2020-12-21 19:35:45','2020-12-21 19:36:33');
/*!40000 ALTER TABLE `tblveiculos` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-12-21 16:37:36
